package sectorWork;

public class MyTestClass {

	public static void main(String[] args){
		Fat32_reader myPhat = new Fat32_reader();
	}
}
